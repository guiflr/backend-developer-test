"use strict";
describe('Test', () => {
    test('Should be true', () => {
        expect(true).toBe(true);
    });
});
